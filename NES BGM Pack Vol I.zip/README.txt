Thanks for downloading this sounds pack [!]
Produced by: Diablo Luna -> @PudreteDiablo

LICENSE:
You can freely use the audio files (even edit them or sell your project with sounds included) of the current pack. Credits are totally optional, but you are not allowed to sell this sounds pack by it self and neither to present it as if it were of your authorship.

Support me through Patreon: patreon.com/PudreteDiablo
[!] Gift me a "follow": fanlink.to/PudreteDiablo